//
//  ViewController.swift
//  day3
//
//  Created by MacStudent on 2018-02-22.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

class RegisterVC: UIViewController,UIPickerViewDelegate, UIPickerViewDataSource {
    
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent noofrowsincomponent: Int) -> Int {
        return self.citylist.count
        
    }

    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int)  -> String? {
        return self.citylist[row]
    }
    
    
    @IBOutlet weak var txtName: UITextField!
    
    @IBOutlet weak var txtPassword: UITextField!
    
    
    @IBOutlet weak var txtContactNumber: UITextField!
    
    
    @IBOutlet weak var datePicker: UIDatePicker!
    
    @IBOutlet weak var cityPicker: UIPickerView!
    
    @IBOutlet weak var txtPostalCode: UITextField!
    
    
    
    @IBOutlet weak var txtEmail: UITextField!
    
    @IBOutlet weak var txtDateOfBirth: UITextField!
    
    var citylist: [String] = [ "vancouver", "calgary", "brampton", "toronto"]
    
    var selectCityIndex: Int = 0
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        // add data in picker
        self.cityPicker.delegate = self
        self.cityPicker.dataSource = self
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    
    @objc private func displayValues() {
        self.selectCityIndex = self.cityPicker.selectedRow(inComponent: 0)
        
        let allData: String = "(self.txtName.text!)\n\(self.txtPassword.text!)\n\(self.txtContactNumber.text!)\n\(self.txtDateOfBirth.text!)\n\(self.citylist[selectCityIndex])\n\(self.txtPostalCode.text!)\n\(self.txtEmail.text!)"
    
    
let infoAlert = UIAlertController(title: "verify your details", message: allData, preferredStyle: .actionSheet)
        
        
        infoAlert.addAction(UIAlertAction(title: "cancel", style: .destructive, handler: nil))
        infoAlert.addAction(UIAlertAction(title: "confirm", style: .default, handler: {
            self.displayWelcomeScreen()}))
        
        self.present(infoAlert, animated: true, completion: nil)
    
    }
}
