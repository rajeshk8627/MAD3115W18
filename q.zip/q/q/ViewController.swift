//
//  ViewController.swift
//  q
//
//  Created by MacStudent on 2018-02-27.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var txtCarColor: UITextField!
     @IBOutlet weak var txtCarPlate: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
   
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


    func writePropertyList(){
        //create new dictionary element
        let myCar = NSMutableDictionary()
        myCar["carPlate"] = self.txtCarPlate.text
        myCar["carColor"] = self.txtCarColor.text
        if let plistPath = Bundle.main.path(forResource: "cars",
        ofType: "plist"){
        let carplist = NSMutableArray(contentsOfFile: plistPath)
            carplist?.add(myCar)
            if (carplist?.write(toFile: plistPath, atomically: true))!
            {
            print("carslist: \(String(describing: carplist))")
            }
            
            }
        
                                            
    
    else{
            print("unable to locate plist file")
        }
}
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}

